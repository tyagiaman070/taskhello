import * as React from "react";
import { useState } from "react";
import { Form, FormGroup, Label, Input, Container, Button } from "reactstrap";
import ListCars from "./ListCars";

const Home = () => {
  const [carForm, setCarForm] = useState({
    brandName: "",
    brandModel: "",
    carQuantity: 0,
  });

  const [carList, setCarList] = useState([]);

  console.log(carList);
  console.log(carForm);

  const handleFormChange = (e) => {
    setCarForm({ ...carForm, [e.target.name]: e.target.value });
  };

  const handleFormSubmit = () => {
    // setCarList((carList) => {
    let flag = 0;
    for (let i = 0; i < carList.length; i++) {
      if (
        carList[i].brandModel === carForm.brandModel &&
        carList[i].brandName === carForm.brandName
      ) {
        console.log("I am inside if");
        // setCarList({...carList, })
        carList[i].carQuantity = carList[i].carQuantity + carForm.carQuantity;
        flag = 1;
      }
    }
    // })

    console.log(flag);

    if (flag === 0) {
      carList.push({
        brandName: carForm.brandName,
        brandModel: carForm.brandModel,
        carQuantity: carForm.carQuantity,
      });
      console.log("insdie puch");
    }
    // setCarForm({
    //   brandName: "",
    //   brandModel: "",
    //   carQuantity: 0,
    // });
  };

  return (
    <div className="App">
      <Container>
        <h1>Home Component</h1>
        <Form>
          <FormGroup>
            <Label for="brandName">Brand Name</Label>
            <Input
              id="brandName"
              name="brandName"
              placeholder="Enter Brand Name"
              type="text"
              onChange={handleFormChange}
            />
          </FormGroup>
          <FormGroup>
            <Label for="brandModel">Car Model</Label>
            <Input
              id="brandModel"
              name="brandModel"
              placeholder="Enter brand model"
              type="text"
              onChange={handleFormChange}
            />
          </FormGroup>
          <FormGroup>
            <Label for="carQuantity">Car Quantity</Label>
            <Input
              id="carQuantity"
              name="carQuantity"
              placeholder="Enter Car Quantity"
              type="text"
              onChange={handleFormChange}
            />
          </FormGroup>

          <Button onClick={handleFormSubmit}>Submit</Button>
        </Form>

        <ListCars carList={carList} />
      </Container>
    </div>
  );
};

export default Home;
