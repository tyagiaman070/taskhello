import * as React from "react";
import { ListGroup, ListGroupItem, Badge } from "reactstrap";

const ListCars = ({ carList }) => {
  return (
    <div className="App">
      <h1>List Car Component</h1>
      {carList.length > 0 ? (
        <ListGroup>
          {carList.map((car, i) => (
            <ListGroupItem key={i} className="justify-content-between">
              Brand Name : {car.brandName}, brandModel: {car.brandModel}
              <Badge pill>{car.carQuantity}</Badge>
            </ListGroupItem>
          ))}
        </ListGroup>
      ) : (
        <h1>No Car available in list</h1>
      )}
    </div>
  );
};

export default ListCars;
